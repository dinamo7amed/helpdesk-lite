import type { User, Ticket, HelpArticle } from '@/types';

export const mockUsers: User[] = [
  {
    id: 'u1',
    name: 'Alex Morgan',
    email: 'alex.morgan@company.com',
    role: 'employee',
    department: 'Marketing',
  },
  {
    id: 'u2',
    name: 'Priya Sharma',
    email: 'priya.sharma@company.com',
    role: 'employee',
    department: 'Finance',
  },
  {
    id: 'u3',
    name: 'David Chen',
    email: 'david.chen@company.com',
    role: 'employee',
    department: 'Operations',
  },
  {
    id: 'u4',
    name: 'Sara Williams',
    email: 'sara.williams@company.com',
    role: 'employee',
    department: 'HR',
  },
  {
    id: 'u5',
    name: 'Marcus Johnson',
    email: 'marcus.johnson@company.com',
    role: 'employee',
    department: 'Sales',
  },
  {
    id: 'u6',
    name: 'Emily Davis',
    email: 'emily.davis@company.com',
    role: 'support',
    department: 'IT Support',
  },
  {
    id: 'u7',
    name: 'James Rodriguez',
    email: 'james.rodriguez@company.com',
    role: 'support',
    department: 'IT Support',
  },
  {
    id: 'u8',
    name: 'Linda Park',
    email: 'linda.park@company.com',
    role: 'support',
    department: 'IT Support',
  },
  {
    id: 'u9',
    name: 'Robert Taylor',
    email: 'robert.taylor@company.com',
    role: 'manager',
    department: 'IT Operations',
  },
  {
    id: 'u10',
    name: 'Nina Patel',
    email: 'nina.patel@company.com',
    role: 'manager',
    department: 'IT Operations',
  },
];

const now = new Date();
const daysAgo = (n: number) => {
  const d = new Date(now);
  d.setDate(d.getDate() - n);
  return d.toISOString();
};

export const mockTickets: Ticket[] = [
  {
    id: 'TKT-1001',
    subject: 'Laptop screen flickering after sleep',
    description:
      'My laptop screen flickers for about 10 seconds after waking from sleep mode. It started happening after the recent OS update.',
    category: 'Hardware',
    priority: 'Medium',
    status: 'Open',
    createdBy: 'u1',
    createdByName: 'Alex Morgan',
    assignedTo: null,
    assignedToName: null,
    createdAt: daysAgo(1),
    updatedAt: daysAgo(1),
    comments: [],
  },
  {
    id: 'TKT-1002',
    subject: 'Cannot access VPN from home network',
    description:
      'I am unable to connect to the company VPN from my home network. I have tried restarting my router and reinstalling the VPN client.',
    category: 'Network',
    priority: 'High',
    status: 'In Progress',
    createdBy: 'u2',
    createdByName: 'Priya Sharma',
    assignedTo: 'u6',
    assignedToName: 'Emily Davis',
    createdAt: daysAgo(2),
    updatedAt: daysAgo(1),
    comments: [
      {
        id: 'c1',
        authorId: 'u6',
        authorName: 'Emily Davis',
        content:
          'I am looking into this. Can you share your VPN client version and the error message you see?',
        createdAt: daysAgo(1),
      },
    ],
  },
  {
    id: 'TKT-1003',
    subject: 'Email signature not displaying correctly',
    description:
      'My email signature is showing raw HTML instead of the formatted version in Outlook. Other colleagues can see it fine.',
    category: 'Email',
    priority: 'Low',
    status: 'Resolved',
    createdBy: 'u3',
    createdByName: 'David Chen',
    assignedTo: 'u7',
    assignedToName: 'James Rodriguez',
    createdAt: daysAgo(5),
    updatedAt: daysAgo(3),
    comments: [
      {
        id: 'c2',
        authorId: 'u7',
        authorName: 'James Rodriguez',
        content:
          'This was a formatting issue in Outlook. I have reset your signature profile. Please restart Outlook.',
        createdAt: daysAgo(3),
      },
      {
        id: 'c3',
        authorId: 'u3',
        authorName: 'David Chen',
        content: 'That worked, thank you!',
        createdAt: daysAgo(3),
      },
    ],
  },
  {
    id: 'TKT-1004',
    subject: 'Slack app keeps crashing on startup',
    description:
      'The Slack desktop app crashes immediately after opening. I have tried reinstalling it twice.',
    category: 'Software',
    priority: 'Medium',
    status: 'Open',
    createdBy: 'u4',
    createdByName: 'Sara Williams',
    assignedTo: null,
    assignedToName: null,
    createdAt: daysAgo(1),
    updatedAt: daysAgo(1),
    comments: [],
  },
  {
    id: 'TKT-1005',
    subject: 'Need access to Salesforce dashboard',
    description:
      'I recently joined the Sales team and need access to the Salesforce dashboard for reporting.',
    category: 'Account',
    priority: 'High',
    status: 'In Progress',
    createdBy: 'u5',
    createdByName: 'Marcus Johnson',
    assignedTo: 'u8',
    assignedToName: 'Linda Park',
    createdAt: daysAgo(3),
    updatedAt: daysAgo(2),
    comments: [
      {
        id: 'c4',
        authorId: 'u8',
        authorName: 'Linda Park',
        content:
          'I have submitted the access request to the Salesforce admin. It usually takes 24-48 hours.',
        createdAt: daysAgo(2),
      },
    ],
  },
  {
    id: 'TKT-1006',
    subject: 'Printer on 3rd floor not responding',
    description:
      'The shared printer on the 3rd floor (HP LaserJet) is not responding to any print jobs. The display shows no error.',
    category: 'Hardware',
    priority: 'Urgent',
    status: 'In Progress',
    createdBy: 'u1',
    createdByName: 'Alex Morgan',
    assignedTo: 'u6',
    assignedToName: 'Emily Davis',
    createdAt: daysAgo(2),
    updatedAt: daysAgo(1),
    comments: [
      {
        id: 'c5',
        authorId: 'u6',
        authorName: 'Emily Davis',
        content:
          'I am on my way to check the printer. It may be a network port issue.',
        createdAt: daysAgo(1),
      },
    ],
  },
  {
    id: 'TKT-1007',
    subject: 'Password reset for Jira account',
    description: 'I forgot my Jira password and the reset email is not arriving.',
    category: 'Account',
    priority: 'Medium',
    status: 'Closed',
    createdBy: 'u2',
    createdByName: 'Priya Sharma',
    assignedTo: 'u7',
    assignedToName: 'James Rodriguez',
    createdAt: daysAgo(10),
    updatedAt: daysAgo(8),
    comments: [
      {
        id: 'c6',
        authorId: 'u7',
        authorName: 'James Rodriguez',
        content: 'Password has been reset manually. Check your inbox.',
        createdAt: daysAgo(8),
      },
    ],
  },
  {
    id: 'TKT-1008',
    subject: 'Dual monitor setup not detected',
    description:
      'I got a second monitor but my laptop is not detecting it. I am using a USB-C dock.',
    category: 'Hardware',
    priority: 'Low',
    status: 'Open',
    createdBy: 'u3',
    createdByName: 'David Chen',
    assignedTo: null,
    assignedToName: null,
    createdAt: daysAgo(1),
    updatedAt: daysAgo(1),
    comments: [],
  },
  {
    id: 'TKT-1009',
    subject: 'Office 365 license expired warning',
    description:
      'I keep getting a warning that my Office 365 license has expired, but I should have an active license through the company.',
    category: 'Software',
    priority: 'High',
    status: 'Resolved',
    createdBy: 'u4',
    createdByName: 'Sara Williams',
    assignedTo: 'u8',
    assignedToName: 'Linda Park',
    createdAt: daysAgo(6),
    updatedAt: daysAgo(4),
    comments: [
      {
        id: 'c7',
        authorId: 'u8',
        authorName: 'Linda Park',
        content:
          'Your license was accidentally removed during the last batch update. I have re-added it.',
        createdAt: daysAgo(4),
      },
    ],
  },
  {
    id: 'TKT-1010',
    subject: 'Wi-Fi keeps dropping in conference room B',
    description:
      'The Wi-Fi signal in conference room B drops every few minutes during meetings. This is affecting our client calls.',
    category: 'Network',
    priority: 'Urgent',
    status: 'Open',
    createdBy: 'u5',
    createdByName: 'Marcus Johnson',
    assignedTo: null,
    assignedToName: null,
    createdAt: daysAgo(1),
    updatedAt: daysAgo(1),
    comments: [],
  },
  {
    id: 'TKT-1011',
    subject: 'Request for new wireless mouse',
    description:
      'My current mouse is not working properly and I would like to request a replacement wireless mouse.',
    category: 'Hardware',
    priority: 'Low',
    status: 'Closed',
    createdBy: 'u1',
    createdByName: 'Alex Morgan',
    assignedTo: 'u6',
    assignedToName: 'Emily Davis',
    createdAt: daysAgo(15),
    updatedAt: daysAgo(12),
    comments: [
      {
        id: 'c8',
        authorId: 'u6',
        authorName: 'Emily Davis',
        content: 'A new mouse has been dispatched to your desk. It should arrive today.',
        createdAt: daysAgo(13),
      },
    ],
  },
  {
    id: 'TKT-1012',
    subject: 'Cannot open .pdf attachments in Outlook',
    description:
      'When I try to open PDF attachments from Outlook, nothing happens. I can open them from the web client.',
    category: 'Software',
    priority: 'Medium',
    status: 'In Progress',
    createdBy: 'u2',
    createdByName: 'Priya Sharma',
    assignedTo: 'u7',
    assignedToName: 'James Rodriguez',
    createdAt: daysAgo(3),
    updatedAt: daysAgo(2),
    comments: [
      {
        id: 'c9',
        authorId: 'u7',
        authorName: 'James Rodriguez',
        content:
          'This looks like a file association issue. I will remote in to fix it.',
        createdAt: daysAgo(2),
      },
    ],
  },
  {
    id: 'TKT-1013',
    subject: 'Shared drive not mounting on Mac',
    description:
      'The shared company drive is not mounting on my Mac after the recent security update.',
    category: 'Network',
    priority: 'High',
    status: 'Open',
    createdBy: 'u3',
    createdByName: 'David Chen',
    assignedTo: null,
    assignedToName: null,
    createdAt: daysAgo(1),
    updatedAt: daysAgo(1),
    comments: [],
  },
  {
    id: 'TKT-1014',
    subject: 'Two-factor authentication code not arriving',
    description:
      'I am not receiving the 2FA codes on my phone for the past two days. I am locked out of several systems.',
    category: 'Account',
    priority: 'Urgent',
    status: 'In Progress',
    createdBy: 'u4',
    createdByName: 'Sara Williams',
    assignedTo: 'u8',
    assignedToName: 'Linda Park',
    createdAt: daysAgo(2),
    updatedAt: daysAgo(1),
    comments: [
      {
        id: 'c10',
        authorId: 'u8',
        authorName: 'Linda Park',
        content:
          'I am re-registering your phone number with the 2FA service. Please stand by.',
        createdAt: daysAgo(1),
      },
    ],
  },
  {
    id: 'TKT-1015',
    subject: 'Blue screen error on startup',
    description:
      'My work laptop shows a blue screen error every time I start it up. The error code is MEMORY_MANAGEMENT.',
    category: 'Hardware',
    priority: 'Urgent',
    status: 'Resolved',
    createdBy: 'u5',
    createdByName: 'Marcus Johnson',
    assignedTo: 'u6',
    assignedToName: 'Emily Davis',
    createdAt: daysAgo(7),
    updatedAt: daysAgo(5),
    comments: [
      {
        id: 'c11',
        authorId: 'u6',
        authorName: 'Emily Davis',
        content:
          'One of your RAM modules was faulty. I have replaced it and the laptop boots fine now.',
        createdAt: daysAgo(5),
      },
    ],
  },
  {
    id: 'TKT-1016',
    subject: 'Request for Adobe Creative Cloud license',
    description:
      'I need an Adobe Creative Cloud license for design work on the new marketing campaign.',
    category: 'Software',
    priority: 'Medium',
    status: 'Open',
    createdBy: 'u1',
    createdByName: 'Alex Morgan',
    assignedTo: null,
    assignedToName: null,
    createdAt: daysAgo(1),
    updatedAt: daysAgo(1),
    comments: [],
  },
  {
    id: 'TKT-1017',
    subject: 'Calendar invites not showing in Outlook',
    description:
      'Meeting invites I receive are not appearing on my Outlook calendar, though they show up on the web version.',
    category: 'Email',
    priority: 'Low',
    status: 'Closed',
    createdBy: 'u2',
    createdByName: 'Priya Sharma',
    assignedTo: 'u7',
    assignedToName: 'James Rodriguez',
    createdAt: daysAgo(12),
    updatedAt: daysAgo(10),
    comments: [
      {
        id: 'c12',
        authorId: 'u7',
        authorName: 'James Rodriguez',
        content: 'Calendar sync was disabled in your profile. It is fixed now.',
        createdAt: daysAgo(10),
      },
    ],
  },
  {
    id: 'TKT-1018',
    subject: 'New employee onboarding setup',
    description:
      'We have a new hire starting Monday. Please set up their laptop, accounts, and email.',
    category: 'Account',
    priority: 'High',
    status: 'In Progress',
    createdBy: 'u4',
    createdByName: 'Sara Williams',
    assignedTo: 'u8',
    assignedToName: 'Linda Park',
    createdAt: daysAgo(4),
    updatedAt: daysAgo(2),
    comments: [
      {
        id: 'c13',
        authorId: 'u8',
        authorName: 'Linda Park',
        content:
          'Laptop is being imaged. Accounts will be created by end of day Friday.',
        createdAt: daysAgo(2),
      },
    ],
  },
  {
    id: 'TKT-1019',
    subject: 'Headphone jack not working',
    description:
      'The headphone jack on my desktop does not detect when I plug in my headset.',
    category: 'Hardware',
    priority: 'Low',
    status: 'Open',
    createdBy: 'u3',
    createdByName: 'David Chen',
    assignedTo: null,
    assignedToName: null,
    createdAt: daysAgo(1),
    updatedAt: daysAgo(1),
    comments: [],
  },
  {
    id: 'TKT-1020',
    subject: 'Internal website certificate error',
    description:
      'When accessing the internal HR portal, I get a certificate warning in Chrome and Firefox.',
    category: 'Network',
    priority: 'Medium',
    status: 'Resolved',
    createdBy: 'u5',
    createdByName: 'Marcus Johnson',
    assignedTo: 'u6',
    assignedToName: 'Emily Davis',
    createdAt: daysAgo(8),
    updatedAt: daysAgo(6),
    comments: [
      {
        id: 'c14',
        authorId: 'u6',
        authorName: 'Emily Davis',
        content:
          'The SSL certificate was renewed. You may need to clear your browser cache.',
        createdAt: daysAgo(6),
      },
    ],
  },
];

export const mockHelpArticles: HelpArticle[] = [
  {
    id: 'h1',
    title: 'How to Reset Your Password',
    category: 'Account',
    excerpt:
      'Step-by-step guide to resetting your company account password using the self-service portal.',
    content:
      'If you have forgotten your password, you can reset it through the self-service portal.\n\n1. Go to the company SSO login page.\n2. Click "Forgot Password".\n3. Enter your company email address.\n4. You will receive a reset link valid for 30 minutes.\n5. Click the link and choose a new password that meets the security policy (at least 12 characters, one uppercase, one number, one symbol).\n\nIf you do not receive the email within 5 minutes, check your spam folder or contact IT support.',
    updatedAt: daysAgo(5),
  },
  {
    id: 'h2',
    title: 'Setting Up VPN Access From Home',
    category: 'Network',
    excerpt:
      'Learn how to install and configure the company VPN client to work remotely.',
    content:
      'To connect to the company network from home, you need the approved VPN client.\n\n1. Download the VPN client from the IT software portal.\n2. Install it with administrator privileges.\n3. Open the client and enter the server address: vpn.company.com.\n4. Log in with your company SSO credentials.\n5. Approve the 2FA prompt on your phone.\n\nIf the connection drops frequently, try switching to a wired connection or moving closer to your router. For persistent issues, open a ticket under the "Network" category.',
    updatedAt: daysAgo(8),
  },
  {
    id: 'h3',
    title: 'Configuring Your Email Signature',
    category: 'Email',
    excerpt:
      'Add a professional email signature in Outlook and the web mail client.',
    content:
      'A consistent email signature helps maintain a professional image.\n\nIn Outlook Desktop:\n1. Go to File > Options > Mail > Signatures.\n2. Click "New" and give your signature a name.\n3. Type your signature in the editor. Use the toolbar for formatting.\n4. Select your signature for new messages and replies.\n5. Click OK to save.\n\nIn Outlook Web:\n1. Click the gear icon > Mail > Compose and reply.\n2. Enter your signature in the text box.\n3. Check "Automatically include my signature on messages I send".\n4. Click Save.',
    updatedAt: daysAgo(12),
  },
  {
    id: 'h4',
    title: 'Troubleshooting Common Printer Issues',
    category: 'Hardware',
    excerpt:
      'Fix paper jams, connectivity problems, and print queue errors on shared office printers.',
    content:
      'Most printer problems can be resolved with a few simple steps.\n\nPrinter not responding:\n1. Check that the printer is powered on and connected to the network.\n2. Restart the printer and wait 60 seconds.\n3. On your computer, remove and re-add the printer.\n\nPaper jams:\n1. Open the printer access panels.\n2. Gently pull the paper in the direction it feeds.\n3. Check for small torn pieces left inside.\n\nPrint jobs stuck in queue:\n1. Open the print queue on your computer.\n2. Cancel all pending jobs.\n3. Restart the Print Spooler service.\n\nIf the issue persists, note the printer model and any error codes on the display, then open a ticket.',
    updatedAt: daysAgo(15),
  },
  {
    id: 'h5',
    title: 'Requesting New Software or Licenses',
    category: 'Software',
    excerpt:
      'How to request new applications or additional licenses through the IT portal.',
    content:
      'If you need software that is not already installed on your machine, you can request it through the IT portal.\n\n1. Go to the IT Service Portal.\n2. Click "Request Software".\n3. Search for the application or enter the name if it is not listed.\n4. Provide a business justification.\n5. Your manager will receive an approval request.\n\nStandard applications (browsers, office suites) are usually approved automatically. Specialized software may take 3-5 business days depending on licensing availability and budget approval.',
    updatedAt: daysAgo(20),
  },
];
