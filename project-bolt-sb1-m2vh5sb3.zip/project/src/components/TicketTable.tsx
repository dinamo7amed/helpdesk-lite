import { useNavigate } from 'react-router-dom';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { StatusBadge, PriorityBadge } from '@/components/StatusBadge';
import { EmptyState } from '@/components/EmptyState';
import type { Ticket } from '@/types';
import { formatDate } from '@/lib/format';

interface TicketTableProps {
  tickets: Ticket[];
  emptyTitle?: string;
  emptyDescription?: string;
}

export function TicketTable({
  tickets,
  emptyTitle = 'No tickets found',
  emptyDescription = 'Try adjusting your search or filters.',
}: TicketTableProps) {
  const navigate = useNavigate();

  if (tickets.length === 0) {
    return <EmptyState title={emptyTitle} description={emptyDescription} />;
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50 hover:bg-muted/50">
            <TableHead className="w-28">Ticket ID</TableHead>
            <TableHead>Subject</TableHead>
            <TableHead className="w-28">Priority</TableHead>
            <TableHead className="w-32">Status</TableHead>
            <TableHead className="w-40">Assigned To</TableHead>
            <TableHead className="w-32">Created</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {tickets.map((ticket) => (
            <TableRow
              key={ticket.id}
              className="cursor-pointer transition-colors hover:bg-muted/40"
              onClick={() => navigate(`/tickets/${ticket.id}`)}
            >
              <TableCell className="font-mono text-xs font-medium text-primary">
                {ticket.id}
              </TableCell>
              <TableCell className="font-medium">{ticket.subject}</TableCell>
              <TableCell>
                <PriorityBadge priority={ticket.priority} />
              </TableCell>
              <TableCell>
                <StatusBadge status={ticket.status} />
              </TableCell>
              <TableCell className="text-sm text-muted-foreground">
                {ticket.assignedToName ?? (
                  <span className="italic text-muted-foreground/70">Unassigned</span>
                )}
              </TableCell>
              <TableCell className="text-sm text-muted-foreground">
                {formatDate(ticket.createdAt)}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
