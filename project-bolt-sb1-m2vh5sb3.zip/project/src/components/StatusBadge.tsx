import { cn } from '@/lib/utils';
import type { TicketStatus, Priority } from '@/types';
import { Badge } from '@/components/ui/badge';

const statusStyles: Record<TicketStatus, string> = {
  Open: 'bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300',
  'In Progress':
    'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  Resolved:
    'bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300',
  Closed: 'bg-gray-200 text-gray-600 dark:bg-gray-500/15 dark:text-gray-300',
};

const priorityStyles: Record<Priority, string> = {
  Low: 'bg-gray-100 text-gray-600 dark:bg-gray-500/15 dark:text-gray-300',
  Medium: 'bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300',
  High: 'bg-orange-100 text-orange-700 dark:bg-orange-500/15 dark:text-orange-300',
  Urgent: 'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300',
};

export function StatusBadge({ status }: { status: TicketStatus }) {
  return (
    <Badge
      variant="secondary"
      className={cn('font-medium border-0', statusStyles[status])}
    >
      <span
        className={cn(
          'mr-1.5 inline-block h-1.5 w-1.5 rounded-full',
          status === 'Open' && 'bg-blue-500',
          status === 'In Progress' && 'bg-amber-500',
          status === 'Resolved' && 'bg-green-500',
          status === 'Closed' && 'bg-gray-400'
        )}
      />
      {status}
    </Badge>
  );
}

export function PriorityBadge({ priority }: { priority: Priority }) {
  return (
    <Badge
      variant="secondary"
      className={cn('font-medium border-0', priorityStyles[priority])}
    >
      {priority}
    </Badge>
  );
}
