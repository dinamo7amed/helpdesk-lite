import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import type { Ticket, User, Role, Comment } from '@/types';
import { mockTickets, mockUsers } from '@/data/mockData';

interface AppContextValue {
  tickets: Ticket[];
  users: User[];
  currentUser: User | null;
  login: (role: Role) => void;
  logout: () => void;
  createTicket: (
    data: Omit<
      Ticket,
      | 'id'
      | 'status'
      | 'createdBy'
      | 'createdByName'
      | 'assignedTo'
      | 'assignedToName'
      | 'createdAt'
      | 'updatedAt'
      | 'comments'
    >
  ) => Ticket;
  updateTicket: (id: string, updates: Partial<Ticket>) => void;
  addComment: (ticketId: string, content: string) => void;
  getUserById: (id: string) => User | undefined;
}

const AppContext = createContext<AppContextValue | undefined>(undefined);

const TICKET_ID_KEY = 'helpdesk-ticket-counter';
const STORAGE_KEY = 'helpdesk-tickets';

function loadTickets(): Ticket[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) return JSON.parse(stored) as Ticket[];
  } catch {
    // ignore
  }
  return mockTickets;
}

function loadTicketCounter(): number {
  const stored = localStorage.getItem(TICKET_ID_KEY);
  if (stored) return parseInt(stored, 10);
  return 1021;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [tickets, setTickets] = useState<Ticket[]>(loadTickets);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [ticketCounter, setTicketCounter] = useState<number>(loadTicketCounter);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tickets));
  }, [tickets]);

  useEffect(() => {
    localStorage.setItem(TICKET_ID_KEY, String(ticketCounter));
  }, [ticketCounter]);

  const login = (role: Role) => {
    const user = mockUsers.find((u) => u.role === role);
    if (user) setCurrentUser(user);
  };

  const logout = () => setCurrentUser(null);

  const createTicket: AppContextValue['createTicket'] = (data) => {
    const id = `TKT-${ticketCounter}`;
    const newTicket: Ticket = {
      ...data,
      id,
      status: 'Open',
      createdBy: currentUser?.id ?? 'u1',
      createdByName: currentUser?.name ?? 'Alex Morgan',
      assignedTo: null,
      assignedToName: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      comments: [],
    };
    setTickets((prev) => [newTicket, ...prev]);
    setTicketCounter((c) => c + 1);
    return newTicket;
  };

  const updateTicket: AppContextValue['updateTicket'] = (id, updates) => {
    setTickets((prev) =>
      prev.map((t) =>
        t.id === id ? { ...t, ...updates, updatedAt: new Date().toISOString() } : t
      )
    );
  };

  const addComment: AppContextValue['addComment'] = (ticketId, content) => {
    if (!currentUser) return;
    const comment: Comment = {
      id: `c-${Date.now()}`,
      authorId: currentUser.id,
      authorName: currentUser.name,
      content,
      createdAt: new Date().toISOString(),
    };
    setTickets((prev) =>
      prev.map((t) =>
        t.id === ticketId
          ? { ...t, comments: [...t.comments, comment], updatedAt: comment.createdAt }
          : t
      )
    );
  };

  const getUserById = (id: string) => mockUsers.find((u) => u.id === id);

  const value = useMemo<AppContextValue>(
    () => ({
      tickets,
      users: mockUsers,
      currentUser,
      login,
      logout,
      createTicket,
      updateTicket,
      addComment,
      getUserById,
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [tickets, currentUser, ticketCounter]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components
export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
