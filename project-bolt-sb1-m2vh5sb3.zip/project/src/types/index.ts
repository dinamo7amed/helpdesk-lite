export type Role = 'employee' | 'support' | 'manager';

export type Priority = 'Low' | 'Medium' | 'High' | 'Urgent';

export type TicketStatus = 'Open' | 'In Progress' | 'Resolved' | 'Closed';

export type Category =
  | 'Hardware'
  | 'Software'
  | 'Network'
  | 'Account'
  | 'Email'
  | 'Other';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  avatar?: string;
  department: string;
}

export interface Comment {
  id: string;
  authorId: string;
  authorName: string;
  content: string;
  createdAt: string;
}

export interface Ticket {
  id: string;
  subject: string;
  description: string;
  category: Category;
  priority: Priority;
  status: TicketStatus;
  createdBy: string;
  createdByName: string;
  assignedTo: string | null;
  assignedToName: string | null;
  createdAt: string;
  updatedAt: string;
  comments: Comment[];
}

export interface HelpArticle {
  id: string;
  title: string;
  category: string;
  excerpt: string;
  content: string;
  updatedAt: string;
}
