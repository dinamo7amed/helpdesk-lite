import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from '@/context/AppContext';
import { ThemeProvider } from '@/context/ThemeContext';
import { Toaster } from 'sonner';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import LoginPage from '@/pages/LoginPage';
import EmployeeDashboard from '@/pages/EmployeeDashboard';
import CreateTicketPage from '@/pages/CreateTicketPage';
import MyTicketsPage from '@/pages/MyTicketsPage';
import TicketDetailsPage from '@/pages/TicketDetailsPage';
import SupportDashboard from '@/pages/SupportDashboard';
import ManagerDashboard from '@/pages/ManagerDashboard';
import HelpCenterPage from '@/pages/HelpCenterPage';
import NotFoundPage from '@/pages/NotFoundPage';

function App() {
  return (
    <ThemeProvider>
      <AppProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<LoginPage />} />
            <Route element={<DashboardLayout />}>
              <Route path="/dashboard" element={<EmployeeDashboard />} />
              <Route path="/tickets/new" element={<CreateTicketPage />} />
              <Route path="/my-tickets" element={<MyTicketsPage />} />
              <Route path="/tickets/:id" element={<TicketDetailsPage />} />
              <Route path="/support" element={<SupportDashboard />} />
              <Route path="/manager" element={<ManagerDashboard />} />
              <Route path="/help-center" element={<HelpCenterPage />} />
            </Route>
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </BrowserRouter>
        <Toaster position="top-right" richColors />
      </AppProvider>
    </ThemeProvider>
  );
}

export default App;
