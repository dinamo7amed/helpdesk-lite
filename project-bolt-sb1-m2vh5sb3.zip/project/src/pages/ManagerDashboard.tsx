import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import { Ticket as TicketIcon, FolderOpen, CheckCircle2, Users } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { StatCard } from '@/components/StatCard';
import { TicketTable } from '@/components/TicketTable';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { StatusBadge, PriorityBadge } from '@/components/StatusBadge';
import type { TicketStatus, Priority } from '@/types';

const statusColors: Record<TicketStatus, string> = {
  Open: 'hsl(221 83% 53%)',
  'In Progress': 'hsl(38 92% 50%)',
  Resolved: 'hsl(142 71% 45%)',
  Closed: 'hsl(215 16% 47%)',
};

const priorityColors: Record<Priority, string> = {
  Low: 'hsl(215 16% 47%)',
  Medium: 'hsl(221 83% 53%)',
  High: 'hsl(38 92% 50%)',
  Urgent: 'hsl(0 84% 60%)',
};

export default function ManagerDashboard() {
  const { tickets, users } = useApp();
  const navigate = useNavigate();

  const stats = useMemo(() => {
    const open = tickets.filter(
      (t) => t.status === 'Open' || t.status === 'In Progress'
    ).length;
    const closed = tickets.filter(
      (t) => t.status === 'Closed' || t.status === 'Resolved'
    ).length;
    const employees = users.filter((u) => u.role === 'employee').length;
    return { total: tickets.length, open, closed, employees };
  }, [tickets, users]);

  const statusData = useMemo(() => {
    const statuses: TicketStatus[] = ['Open', 'In Progress', 'Resolved', 'Closed'];
    return statuses.map((s) => ({
      name: s,
      value: tickets.filter((t) => t.status === s).length,
      color: statusColors[s],
    }));
  }, [tickets]);

  const priorityData = useMemo(() => {
    const priorities: Priority[] = ['Low', 'Medium', 'High', 'Urgent'];
    return priorities.map((p) => ({
      name: p,
      value: tickets.filter((t) => t.priority === p).length,
      fill: priorityColors[p],
    }));
  }, [tickets]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Analytics Dashboard</h1>
        <p className="text-sm text-muted-foreground">
          Overview of all support tickets and team performance.
        </p>
      </div>

      {/* Stat cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total Tickets" value={stats.total} icon={TicketIcon} variant="primary" />
        <StatCard label="Open Tickets" value={stats.open} icon={FolderOpen} variant="warning" />
        <StatCard label="Closed Tickets" value={stats.closed} icon={CheckCircle2} variant="success" />
        <StatCard label="Employees" value={stats.employees} icon={Users} variant="default" />
      </div>

      {/* Charts */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Tickets by Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={90}
                    paddingAngle={3}
                  >
                    {statusData.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      borderRadius: '8px',
                      border: '1px solid hsl(var(--border))',
                      background: 'hsl(var(--popover))',
                      color: 'hsl(var(--popover-foreground))',
                    }}
                  />
                  <Legend
                    verticalAlign="bottom"
                    iconType="circle"
                    wrapperStyle={{ fontSize: '12px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Tickets by Priority</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={priorityData} barSize={48}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="hsl(var(--border))"
                    vertical={false}
                  />
                  <XAxis
                    dataKey="name"
                    tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                    axisLine={false}
                    tickLine={false}
                    allowDecimals={false}
                  />
                  <Tooltip
                    cursor={{ fill: 'hsl(var(--muted))' }}
                    contentStyle={{
                      borderRadius: '8px',
                      border: '1px solid hsl(var(--border))',
                      background: 'hsl(var(--popover))',
                      color: 'hsl(var(--popover-foreground))',
                    }}
                  />
                  <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                    {priorityData.map((entry) => (
                      <Cell key={entry.name} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* All tickets table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">All Tickets</CardTitle>
        </CardHeader>
        <CardContent>
          <TicketTable tickets={tickets} />
        </CardContent>
      </Card>
    </div>
  );
}
