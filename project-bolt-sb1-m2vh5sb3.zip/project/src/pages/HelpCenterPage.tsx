import { useMemo, useState } from 'react';
import { LifeBuoy, Search, BookOpen, ArrowLeft, Clock } from 'lucide-react';
import { mockHelpArticles } from '@/data/mockData';
import { SearchBar } from '@/components/SearchBar';
import { EmptyState } from '@/components/EmptyState';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { formatDate } from '@/lib/format';

export default function HelpCenterPage() {
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const articles = mockHelpArticles;

  const filtered = useMemo(() => {
    if (!search.trim()) return articles;
    return articles.filter(
      (a) =>
        a.title.toLowerCase().includes(search.toLowerCase()) ||
        a.excerpt.toLowerCase().includes(search.toLowerCase()) ||
        a.content.toLowerCase().includes(search.toLowerCase())
    );
  }, [articles, search]);

  const selected = articles.find((a) => a.id === selectedId);

  if (selected) {
    return (
      <div className="mx-auto max-w-3xl space-y-6">
        <Button
          variant="ghost"
          className="gap-2"
          onClick={() => setSelectedId(null)}
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Help Center
        </Button>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
                {selected.category}
              </span>
              <span className="flex items-center gap-1 text-xs">
                <Clock className="h-3 w-3" />
                Updated {formatDate(selected.updatedAt)}
              </span>
            </div>
            <CardTitle className="text-2xl">{selected.title}</CardTitle>
            <CardDescription>{selected.excerpt}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="whitespace-pre-wrap text-sm leading-relaxed text-muted-foreground">
              {selected.content}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Hero */}
      <div className="rounded-2xl bg-gradient-to-r from-primary to-primary/80 p-8 text-primary-foreground">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-foreground/15">
            <LifeBuoy className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Help Center</h1>
            <p className="text-primary-foreground/80">
              Browse our knowledge base for quick answers.
            </p>
          </div>
        </div>
        <div className="mt-5 max-w-md">
          <SearchBar
            value={search}
            onChange={setSearch}
            placeholder="Search articles..."
          />
        </div>
      </div>

      {/* Articles grid */}
      {filtered.length === 0 ? (
        <EmptyState
          title="No articles found"
          description="Try a different search term."
          icon={Search}
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((article) => (
            <Card
              key={article.id}
              className="cursor-pointer transition-all hover:shadow-md hover:border-primary/40"
              onClick={() => setSelectedId(article.id)}
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
                    {article.category}
                  </span>
                  <BookOpen className="h-4 w-4 text-muted-foreground" />
                </div>
                <CardTitle className="mt-2 text-base">{article.title}</CardTitle>
                <CardDescription className="line-clamp-2">
                  {article.excerpt}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  Updated {formatDate(article.updatedAt)}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
