import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { TicketPlus, ListTodo, Ticket as TicketIcon, CheckCircle2, Clock } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { StatCard } from '@/components/StatCard';
import { TicketTable } from '@/components/TicketTable';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { StatusBadge, PriorityBadge } from '@/components/StatusBadge';
import { formatDate } from '@/lib/format';
import type { Ticket } from '@/types';

export default function EmployeeDashboard() {
  const { tickets, currentUser } = useApp();
  const navigate = useNavigate();

  const myTickets = useMemo(
    () => tickets.filter((t) => t.createdBy === currentUser?.id),
    [tickets, currentUser]
  );

  const stats = useMemo(() => {
    const open = myTickets.filter(
      (t) => t.status === 'Open' || t.status === 'In Progress'
    ).length;
    const closed = myTickets.filter(
      (t) => t.status === 'Closed' || t.status === 'Resolved'
    ).length;
    return { total: myTickets.length, open, closed };
  }, [myTickets]);

  const recentTickets = useMemo(
    () =>
      [...myTickets]
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5),
    [myTickets]
  );

  return (
    <div className="space-y-6">
      {/* Welcome banner */}
      <div className="rounded-2xl bg-gradient-to-r from-primary to-primary/80 p-6 text-primary-foreground">
        <h1 className="text-2xl font-bold">Hello, {currentUser?.name.split(' ')[0]}!</h1>
        <p className="mt-1 text-primary-foreground/80">
          Here's an overview of your support tickets.
        </p>
        <div className="mt-4 flex flex-wrap gap-3">
          <Button
            variant="secondary"
            className="gap-2"
            onClick={() => navigate('/tickets/new')}
          >
            <TicketPlus className="h-4 w-4" />
            Create Ticket
          </Button>
          <Button
            variant="secondary"
            className="gap-2"
            onClick={() => navigate('/my-tickets')}
          >
            <ListTodo className="h-4 w-4" />
            View My Tickets
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard
          label="Total Tickets"
          value={stats.total}
          icon={TicketIcon}
          variant="primary"
        />
        <StatCard
          label="Open Tickets"
          value={stats.open}
          icon={Clock}
          variant="warning"
        />
        <StatCard
          label="Closed Tickets"
          value={stats.closed}
          icon={CheckCircle2}
          variant="success"
        />
      </div>

      {/* Recent tickets */}
      <Card>
        <CardHeader className="flex-row items-center justify-between">
          <CardTitle>Recent Tickets</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            className="text-primary"
            onClick={() => navigate('/my-tickets')}
          >
            View all
          </Button>
        </CardHeader>
        <CardContent>
          {recentTickets.length === 0 ? (
            <div className="py-12 text-center">
              <p className="text-sm text-muted-foreground">
                You haven't created any tickets yet.
              </p>
              <Button
                className="mt-3 gap-2"
                onClick={() => navigate('/tickets/new')}
              >
                <TicketPlus className="h-4 w-4" />
                Create your first ticket
              </Button>
            </div>
          ) : (
            <div className="space-y-2">
              {recentTickets.map((ticket: Ticket) => (
                <div
                  key={ticket.id}
                  className="flex cursor-pointer items-center gap-4 rounded-lg border p-3 transition-colors hover:bg-muted/50"
                  onClick={() => navigate(`/tickets/${ticket.id}`)}
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                    <TicketIcon className="h-5 w-5 text-primary" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{ticket.subject}</p>
                    <p className="text-xs text-muted-foreground">
                      {ticket.id} - {formatDate(ticket.createdAt)}
                    </p>
                  </div>
                  <div className="hidden gap-2 sm:flex">
                    <PriorityBadge priority={ticket.priority} />
                    <StatusBadge status={ticket.status} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
