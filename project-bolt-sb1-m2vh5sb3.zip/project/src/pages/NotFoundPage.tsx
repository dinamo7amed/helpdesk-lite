import { useNavigate } from 'react-router-dom';
import { Compass, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function NotFoundPage() {
  const navigate = useNavigate();

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background p-4 text-center">
      <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-primary/10">
        <Compass className="h-10 w-10 text-primary" />
      </div>
      <h1 className="mt-6 text-6xl font-bold text-primary">404</h1>
      <h2 className="mt-2 text-xl font-semibold">Page not found</h2>
      <p className="mt-2 max-w-sm text-sm text-muted-foreground">
        The page you're looking for doesn't exist or has been moved.
      </p>
      <Button className="mt-6 gap-2" onClick={() => navigate('/')}>
        <Home className="h-4 w-4" />
        Back to Home
      </Button>
    </div>
  );
}
