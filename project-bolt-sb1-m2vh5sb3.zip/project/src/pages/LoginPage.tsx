import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Headphones, User, LifeBuoy, BarChart3, ArrowRight } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import type { Role } from '@/types';
import { cn } from '@/lib/utils';

const roleInfo: Record<
  Role,
  { label: string; icon: typeof User; description: string; route: string }
> = {
  employee: {
    label: 'Employee',
    icon: User,
    description: 'Submit and track your support tickets',
    route: '/dashboard',
  },
  support: {
    label: 'Support Agent',
    icon: LifeBuoy,
    description: 'Manage and resolve incoming tickets',
    route: '/support',
  },
  manager: {
    label: 'Manager',
    icon: BarChart3,
    description: 'View analytics and team performance',
    route: '/manager',
  },
};

export default function LoginPage() {
  const { login } = useApp();
  const navigate = useNavigate();
  const [role, setRole] = useState<Role>('employee');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    login(role);
    navigate(roleInfo[role].route);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-primary/5 via-background to-primary/10 p-4">
      <div className="w-full max-w-5xl overflow-hidden rounded-2xl border bg-card shadow-xl lg:grid lg:grid-cols-2">
        {/* Left panel */}
        <div className="hidden flex-col justify-between bg-primary p-10 text-primary-foreground lg:flex">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary-foreground/15">
              <Headphones className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold">HelpDesk Lite</h1>
              <p className="text-sm text-primary-foreground/70">
                Support Ticket System
              </p>
            </div>
          </div>

          <div className="space-y-6">
            <h2 className="text-3xl font-bold leading-tight">
              Manage your IT support, all in one place.
            </h2>
            <p className="text-primary-foreground/80">
              Submit tickets, track progress, and resolve issues faster. A
              streamlined helpdesk experience for employees, support agents,
              and managers.
            </p>
            <div className="space-y-3">
              {Object.values(roleInfo).map((r) => {
                const Icon = r.icon;
                return (
                  <div
                    key={r.label}
                    className="flex items-center gap-3 rounded-lg bg-primary-foreground/10 p-3"
                  >
                    <Icon className="h-5 w-5 shrink-0" />
                    <div>
                      <p className="text-sm font-semibold">{r.label}</p>
                      <p className="text-xs text-primary-foreground/70">
                        {r.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <p className="text-sm text-primary-foreground/60">
            Demo project - No real authentication required
          </p>
        </div>

        {/* Right panel - form */}
        <div className="flex items-center justify-center p-8 lg:p-12">
          <div className="w-full max-w-sm space-y-6">
            <div className="text-center lg:hidden">
              <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-primary">
                <Headphones className="h-6 w-6 text-primary-foreground" />
              </div>
              <h1 className="text-2xl font-bold">HelpDesk Lite</h1>
            </div>

            <div>
              <h2 className="text-2xl font-bold">Sign in</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Choose a role to access the dashboard.
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="name@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter any password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="role">Role</Label>
                <Select
                  value={role}
                  onValueChange={(v) => setRole(v as Role)}
                >
                  <SelectTrigger id="role">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="employee">Employee</SelectItem>
                    <SelectItem value="support">Support Agent</SelectItem>
                    <SelectItem value="manager">Manager</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button type="submit" className="w-full gap-2" size="lg">
                Sign in as {roleInfo[role].label}
                <ArrowRight className="h-4 w-4" />
              </Button>
            </form>

            <p className="text-center text-xs text-muted-foreground">
              This is a demo. Any email and password will work.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
