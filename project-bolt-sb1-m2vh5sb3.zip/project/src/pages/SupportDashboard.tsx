import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Inbox, Loader, CheckCircle2, Headphones } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { StatCard } from '@/components/StatCard';
import { SearchBar } from '@/components/SearchBar';
import { Pagination } from '@/components/Pagination';
import { StatusBadge, PriorityBadge } from '@/components/StatusBadge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { EmptyState } from '@/components/EmptyState';
import { toast } from 'sonner';
import type { TicketStatus } from '@/types';

const PAGE_SIZE = 8;
const statusOptions: (TicketStatus | 'All')[] = [
  'All',
  'Open',
  'In Progress',
  'Resolved',
  'Closed',
];

export default function SupportDashboard() {
  const { tickets, currentUser, updateTicket } = useApp();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<TicketStatus | 'All'>('All');
  const [currentPage, setCurrentPage] = useState(1);

  const stats = useMemo(() => {
    const open = tickets.filter((t) => t.status === 'Open').length;
    const inProgress = tickets.filter((t) => t.status === 'In Progress').length;
    const resolved = tickets.filter(
      (t) => t.status === 'Resolved' || t.status === 'Closed'
    ).length;
    return { open, inProgress, resolved };
  }, [tickets]);

  const filtered = useMemo(() => {
    return tickets.filter((t) => {
      const matchesSearch =
        t.subject.toLowerCase().includes(search.toLowerCase()) ||
        t.id.toLowerCase().includes(search.toLowerCase()) ||
        t.createdByName.toLowerCase().includes(search.toLowerCase());
      const matchesStatus =
        statusFilter === 'All' || t.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [tickets, search, statusFilter]);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paginated = filtered.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE
  );

  const handleAssign = (ticketId: string) => {
    updateTicket(ticketId, {
      assignedTo: currentUser?.id ?? null,
      assignedToName: currentUser?.name ?? null,
      status: 'In Progress',
    });
    toast.success(`Ticket ${ticketId} assigned to you`);
  };

  const handleStatusChange = (ticketId: string, status: TicketStatus) => {
    updateTicket(ticketId, { status });
    toast.success(`Ticket ${ticketId} status changed to ${status}`);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Support Desk</h1>
        <p className="text-sm text-muted-foreground">
          Manage incoming tickets, assign them to yourself, and update their
          status.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard label="New / Open" value={stats.open} icon={Inbox} variant="primary" />
        <StatCard
          label="In Progress"
          value={stats.inProgress}
          icon={Loader}
          variant="warning"
        />
        <StatCard
          label="Resolved / Closed"
          value={stats.resolved}
          icon={CheckCircle2}
          variant="success"
        />
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle>All Tickets</CardTitle>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
              <SearchBar
                value={search}
                onChange={(v) => {
                  setSearch(v);
                  setCurrentPage(1);
                }}
                placeholder="Search tickets..."
                className="sm:w-64"
              />
              <Select
                value={statusFilter}
                onValueChange={(v) => {
                  setStatusFilter(v as TicketStatus | 'All');
                  setCurrentPage(1);
                }}
              >
                <SelectTrigger className="w-full sm:w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {statusOptions.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s === 'All' ? 'All Statuses' : s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {paginated.length === 0 ? (
            <EmptyState
              title="No tickets found"
              description="Try adjusting your search or filters."
            />
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50 hover:bg-muted/50">
                    <TableHead className="w-24">ID</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead className="w-28">Priority</TableHead>
                    <TableHead className="w-36">Status</TableHead>
                    <TableHead className="w-32">Assign</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginated.map((ticket) => (
                    <TableRow
                      key={ticket.id}
                      className="cursor-pointer"
                      onClick={() => navigate(`/tickets/${ticket.id}`)}
                    >
                      <TableCell className="font-mono text-xs font-medium text-primary">
                        {ticket.id}
                      </TableCell>
                      <TableCell>
                        <p className="font-medium">{ticket.subject}</p>
                        <p className="text-xs text-muted-foreground">
                          {ticket.createdByName}
                        </p>
                      </TableCell>
                      <TableCell>
                        <PriorityBadge priority={ticket.priority} />
                      </TableCell>
                      <TableCell
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Select
                          value={ticket.status}
                          onValueChange={(v) =>
                            handleStatusChange(ticket.id, v as TicketStatus)
                          }
                        >
                          <SelectTrigger className="h-8 w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Open">Open</SelectItem>
                            <SelectItem value="In Progress">
                              In Progress
                            </SelectItem>
                            <SelectItem value="Resolved">Resolved</SelectItem>
                            <SelectItem value="Closed">Closed</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        {ticket.assignedTo === currentUser?.id ? (
                          <span className="flex items-center gap-1 text-xs font-medium text-success">
                            <Headphones className="h-3.5 w-3.5" />
                            You
                          </span>
                        ) : (
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 gap-1.5"
                            onClick={() => handleAssign(ticket.id)}
                          >
                            <Headphones className="h-3.5 w-3.5" />
                            Take
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
          {filtered.length > 0 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          )}
        </CardContent>
      </Card>
    </div>
  );
}
