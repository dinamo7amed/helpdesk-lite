import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TicketPlus, SlidersHorizontal } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { SearchBar } from '@/components/SearchBar';
import { TicketTable } from '@/components/TicketTable';
import { Pagination } from '@/components/Pagination';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { TicketStatus } from '@/types';

const PAGE_SIZE = 8;
const statusOptions: (TicketStatus | 'All')[] = [
  'All',
  'Open',
  'In Progress',
  'Resolved',
  'Closed',
];

export default function MyTicketsPage() {
  const { tickets, currentUser } = useApp();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<TicketStatus | 'All'>('All');
  const [currentPage, setCurrentPage] = useState(1);

  const myTickets = useMemo(
    () => tickets.filter((t) => t.createdBy === currentUser?.id),
    [tickets, currentUser]
  );

  const filtered = useMemo(() => {
    return myTickets.filter((t) => {
      const matchesSearch =
        t.subject.toLowerCase().includes(search.toLowerCase()) ||
        t.id.toLowerCase().includes(search.toLowerCase());
      const matchesStatus =
        statusFilter === 'All' || t.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [myTickets, search, statusFilter]);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paginated = filtered.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">My Tickets</h1>
          <p className="text-sm text-muted-foreground">
            {filtered.length} ticket{filtered.length !== 1 ? 's' : ''} found
          </p>
        </div>
        <Button className="gap-2" onClick={() => navigate('/tickets/new')}>
          <TicketPlus className="h-4 w-4" />
          New Ticket
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <SearchBar
              value={search}
              onChange={(v) => {
                setSearch(v);
                setCurrentPage(1);
              }}
              placeholder="Search by subject or ticket ID..."
              className="flex-1"
            />
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="h-4 w-4 text-muted-foreground" />
              <Select
                value={statusFilter}
                onValueChange={(v) => {
                  setStatusFilter(v as TicketStatus | 'All');
                  setCurrentPage(1);
                }}
              >
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {statusOptions.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s === 'All' ? 'All Statuses' : s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <TicketTable
            tickets={paginated}
            emptyTitle="No tickets yet"
            emptyDescription="Create a ticket to get started with IT support."
          />
          {filtered.length > 0 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          )}
        </CardContent>
      </Card>
    </div>
  );
}
